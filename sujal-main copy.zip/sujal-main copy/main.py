from backend.app import app  # FastAPI application entrypoint

# Optional: allow running with `python main.py` using Uvicorn
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
